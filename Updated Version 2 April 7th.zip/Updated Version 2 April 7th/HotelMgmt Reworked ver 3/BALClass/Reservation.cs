﻿using System;
using System.Data;
using DataAccessLayer;

namespace HotelMgmt
{
   public class Reservation
    {
       
        public ReservationDetail CheckRoomAvailability(int customerId, DateTime checkInDate, DateTime checkOutDate)
        {
            string roomType;
            DataTable roomDetails;
            int noOfDays;
            int roomNo;
            float totalCharge = 0;
            ReservationDetail reservationDetail = null;
            try
            {
                noOfDays = (checkOutDate - checkInDate).Days;
                if (noOfDays <= 0)
                {
                    throw new Exception("Sorry the Check Out Date should be greater than Check In Date");
                }
                else
                {
                    DataTable roomTypes = ConnectionDb.GetRoomTypes();
                    Console.WriteLine("The Room Types available are : ");
                    foreach (DataRow dr in roomTypes.Rows)
                    {
                        Console.WriteLine("Room Type - " + dr.ItemArray[0] + "  Charges:--->  " + dr.ItemArray[2]);
                    }
                    Console.WriteLine("");
                    Console.WriteLine("Please choose the Room Type");
                    roomType = Console.ReadLine();
                    bool roomTypeStatus = false;
                    if (roomType == "DX")
                    {
                        totalCharge = noOfDays * 4500;
                        roomTypeStatus = true;
                    }
                    else if (roomType == "GR")
                    {
                        totalCharge = noOfDays * 3000;
                        roomTypeStatus = true;
                    }
                    else
                    {
                        Console.WriteLine("Sorry, please choose DX or GR");
                    }

                    if (roomTypeStatus == true)
                    {
                        Console.WriteLine("The number of days for your stay :" + noOfDays);
                        roomDetails=ConnectionDb.GetRoomDetails(roomType);
                        Console.WriteLine("");

                        Console.WriteLine("Please choose the Room of type: " + roomType);
                        foreach (DataRow dr in roomDetails.Rows)
                        {
                            Console.WriteLine(dr.ItemArray[0] + "  " + dr.ItemArray[1] + "  " + dr.ItemArray[2]);

                        }
                        roomNo = Convert.ToInt32(Console.ReadLine());

                        reservationDetail = new ReservationDetail()
                        {
                            CustomerId = customerId,
                            CheckinDate = checkInDate,
                            CheckoutDate = checkOutDate,
                            RoomNumber = roomNo,
                            RoomType = roomType,
                            StayDuration = noOfDays,
                            TotalCharge = totalCharge
                        };
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return reservationDetail;
        }

        public bool DisplayAndAddBookingDetails(ReservationDetail reservationDetail)
        {
            Console.WriteLine("Your Booking Details are :");
            Console.WriteLine("Room Number: " + reservationDetail.RoomNumber);
            Console.WriteLine("Check In Date: " + reservationDetail.CheckinDate.ToShortDateString());
            Console.WriteLine("Check Out Date: " + reservationDetail.CheckoutDate.ToShortDateString());
            Console.WriteLine("The number of days for your stay :" + (reservationDetail.CheckoutDate - reservationDetail.CheckinDate).Days.ToString());
            Console.WriteLine("Total Charges: " + reservationDetail.TotalCharge.ToString());

            int reservationId = ConnectionDb.AddBooking(reservationDetail.CustomerId, reservationDetail.CheckinDate, reservationDetail.CheckoutDate, reservationDetail.RoomNumber, "Booked", reservationDetail.TotalCharge);
            if (reservationId > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void SearchByDate(DateTime searchDate)
        {
            try
            {
                DataTable searchDateRoomDetails = ConnectionDb.SearchRoomByDate(searchDate);
                if (searchDateRoomDetails.Rows.Count != 0)
                {
                    foreach (DataRow dr in searchDateRoomDetails.Rows)
                    {
                        DateTime checkInDate = Convert.ToDateTime(dr.ItemArray[2]);
                        DateTime checkOutDate = Convert.ToDateTime(dr.ItemArray[3]);
                        Console.WriteLine("Room ID: " + dr.ItemArray[4]);
                        Console.WriteLine("Check In Date: " + checkInDate.ToShortDateString());
                        Console.WriteLine("Check Out Date: " + checkOutDate.ToShortDateString());
                        Console.WriteLine("Total Charges: " + dr.ItemArray[6]);
                    }
                }
                else
                {
                    Console.WriteLine("No booking available for the selected date.");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

    public class ReservationDetail
    {
        public int CustomerId { get; set; }
        public DateTime CheckinDate { get; set; }
        public DateTime CheckoutDate { get; set; }
        public int StayDuration { get; set; }
        public float TotalCharge { get; set; }
        public string RoomType { get; set; }
        public int RoomNumber { get; set; }
        public string ReservationStatus { get; set; }
    }
}
