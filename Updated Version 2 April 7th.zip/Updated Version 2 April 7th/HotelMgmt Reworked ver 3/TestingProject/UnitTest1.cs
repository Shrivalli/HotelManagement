﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HotelMgmt;
using DataAccessLayer;

namespace TestingProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AddBookDetailsTest()
        {
            // Arrange
            int customerId = 101;
            DateTime checkInDate = Convert.ToDateTime("03/02/2010");
            DateTime checkOutDate = Convert.ToDateTime("05/02/2010");
            string expected = "Booked";

            Reservation reserobj = new Reservation();
            ReservationDetail res = new ReservationDetail();

            //// Act
            res=reserobj.CheckRoomAvailability(customerId, checkInDate, checkOutDate);

            //// Assert
            
            string actual = res.ReservationStatus.ToString();
           Console.Write(actual);
            Assert.AreEqual(expected, actual, "Success");
        }
    }
}
