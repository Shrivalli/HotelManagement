﻿using System;
using System.Data;
using HotelMgmt;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAccessLayer;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        
        [TestMethod]
        public void CheckRoomAvailabilityTestPass()
        {
            try
            {
                ConnectionDb.InsertData();
                // Arrange
                DateTime checkInDate = Convert.ToDateTime("03/02/2010");
                int roomNo = 101;
                bool expected = true;

                //// Act
                bool availability = ConnectionDb.ValidateBooking(checkInDate, roomNo);

                //// Assert
                bool actual = availability;
                Console.Write(actual);
                Assert.AreEqual(expected, actual, "Success");
            }
            catch(Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        [TestMethod]
        public void CheckRoomAvailabilityTestFail()
        {
            try
            {
                // Arrange
                ConnectionDb.InsertData();
                DateTime checkInDate = Convert.ToDateTime("09/02/2010");
                int roomNo = 101;
                bool expected = true;

                //// Act
                bool availability = ConnectionDb.ValidateBooking(checkInDate, roomNo);

                //// Assert
                bool actual = availability;
                Console.Write(actual);
                Assert.AreEqual(expected, actual, "Success");
            }
            catch(Exception)
            {
                Assert.Fail("Please check your inputs to get the room availability");
            }
        }

        [TestMethod]
        public void SearchRoomByDateTestpass()
        {
            try
            {
                // Arrange
                ConnectionDb.InsertData();
                DateTime checkInDate = Convert.ToDateTime("03/02/2010");
                string expected = "Booked";
                string actual = null;

                //// Act
                DataTable dtres = ConnectionDb.SearchRoomByDate(checkInDate);
                foreach (DataRow dr in dtres.Rows)
                {
                    actual = dr.ItemArray[5].ToString();
                }
                //// Assert
                Assert.AreEqual(expected, actual, "Success");
            }
            catch(Exception e)
            {
                Assert.Fail(e.Message);
            }
        }
        [TestMethod]
        public void SearchRoomByDateTestfail()
        {
            try
            {
                // Arrange
                ConnectionDb.InsertData();
                DateTime checkInDate = Convert.ToDateTime("03/02/2010");
                string expected = "Available";
                string actual = null;

                //// Act
                DataTable dtres = ConnectionDb.SearchRoomByDate(checkInDate);
                foreach (DataRow dr in dtres.Rows)
                {
                    actual = dr.ItemArray[5].ToString();
                }
                //// Assert
                Assert.AreEqual(expected, actual, "Success");
            }
            catch(Exception)
            {
                Assert.Fail("Please Check the Date format in which you have entered.");
            }
        }

        [TestMethod]
        public void AddBookingTestFail()
        {
            try
            {
                ConnectionDb.InsertData();
                ReservationDetail rdobj = new ReservationDetail();
                rdobj.CustomerId = 189;
                rdobj.RoomNumber = 103;
                rdobj.RoomNumber = 103;
                rdobj.ReservationStatus = "Booked";
                rdobj.TotalCharge = 3000;
                rdobj.CheckinDate = Convert.ToDateTime("03/02/2010");
                rdobj.CheckoutDate = Convert.ToDateTime("03/03/2010");
                bool expected = true;

                //// Act
                Reservation robj = new Reservation();
                bool status = robj.DisplayAndAddBookingDetails(rdobj);
                bool actual = status;

                //// Assert
                Assert.AreEqual(expected, actual, "Success");
            }
            catch(Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        [TestMethod]
        public void AddBookingTestPass()
        {
            try
            {
                ConnectionDb.InsertData();
                ReservationDetail rdobj = new ReservationDetail();
                rdobj.CustomerId = 189;
                rdobj.RoomNumber = 104;
                rdobj.ReservationStatus = "Booked";
                rdobj.TotalCharge = 3000;
                rdobj.CheckinDate = Convert.ToDateTime("10/03/2020");
                rdobj.CheckoutDate = Convert.ToDateTime("15/03/2020");
                bool expected = true;

                //// Act
                Reservation robj = new Reservation();
                bool status = robj.DisplayAndAddBookingDetails(rdobj);
                bool actual = status;

                //// Assert
                Assert.AreEqual(expected, actual, "Success");
            }
            catch (Exception)
            {
              Assert.Fail("Room Booking should be successful with valid input. Exception should not be thrown. Please check the input and application logic");
            }
        }
    }

}




