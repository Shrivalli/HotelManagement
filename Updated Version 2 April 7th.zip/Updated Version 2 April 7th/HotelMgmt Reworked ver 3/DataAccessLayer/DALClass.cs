﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
       public static class ConnectionDb
        {
            public static SqlConnection sqlConnection = null;
            public static SqlCommand sqlCommand = null;
            public static SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            public static DataSet dataset = new DataSet();
            public static DataTable dataTable;
            static readonly string connection = ConfigurationManager.ConnectionStrings["HotelManagement"].ConnectionString;

            public static int InsertData()
            {
            using (sqlConnection = new SqlConnection(connection))
            {
                sqlConnection.Open();
                SqlCommand cmd = new SqlCommand("insert into reservation values(134,'03/02/2010','03/04/2017',101,'Booked',6000)");
                cmd.Connection = sqlConnection;
                int i=cmd.ExecuteNonQuery();
                return i;
            }
            }
        

            public static DataTable GetRoomTypes()
            {
                using (sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    sqlCommand = new SqlCommand("select * from Roomtype", sqlConnection);
                    sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    dataset = new DataSet();
                    sqlDataAdapter.Fill(dataset);
                    dataTable = dataset.Tables[0];
                    return dataTable;
                }
            }

            public static DataTable GetRoomDetails(string roomType)
            {
                using (sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    SqlCommand sqlCommand1 = new SqlCommand("Select * from Room where cRoomType = @rtype", sqlConnection);
                    sqlCommand1.Parameters.AddWithValue("@rtype", roomType);
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand1);
                    DataSet dsRoom = new DataSet();
                    sqlDataAdapter.Fill(dsRoom);
                    DataTable dataTable = dsRoom.Tables[0];
                    return dataTable;
                }
            }

            public static int AddBooking(int customerId, DateTime checkInDate, DateTime checkOutDate, int roomNo, string reservationStatus, float totalCharge)
            {
                bool status = ValidateBooking(checkInDate, roomNo);
                int reservationId = 0;
                using (sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    if (status == false)
                    {

                        sqlCommand = new SqlCommand("insert into reservation values (@cid, @chkin, @chkout, @roomno, @status, @charges)")
                        {
                            Connection = sqlConnection
                        };
                        sqlCommand.Parameters.AddWithValue("@cid", customerId);
                        sqlCommand.Parameters.AddWithValue("@chkin", checkInDate);
                        sqlCommand.Parameters.AddWithValue("@chkout", checkOutDate);
                        sqlCommand.Parameters.AddWithValue("@roomno", roomNo);
                        sqlCommand.Parameters.AddWithValue("@status", reservationStatus);
                        sqlCommand.Parameters.AddWithValue("@charges", totalCharge);
                        reservationId = sqlCommand.ExecuteNonQuery();
                    }

                    return reservationId;
                }
            }

            public static bool ValidateBooking(DateTime checkInDate, int roomNo)
            {
                using (sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    bool flag = false;
                    sqlCommand = new SqlCommand("select * from reservation where dcheckindate = @chkin and iroomno = @rno", sqlConnection);
                    sqlCommand.Parameters.AddWithValue("@chkin", checkInDate);
                    sqlCommand.Parameters.AddWithValue("@rno", roomNo);
                    sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    dataset = new DataSet();
                    sqlDataAdapter.Fill(dataset);
                    dataTable = new DataTable();
                    dataTable = dataset.Tables[0];
                    if (dataTable.Rows.Count > 0)
                    {
                        flag = true;
                    }
                    return flag;
                }
            }

            public static DataTable SearchRoomByDate(DateTime searchDate)
            {
                using (sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    sqlCommand = new SqlCommand("select * from Reservation where dCheckInDate = @searchdt", sqlConnection);
                    sqlCommand.Parameters.AddWithValue("@searchdt", searchDate);
                    sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                    dataset = new DataSet();
                    sqlDataAdapter.Fill(dataset);
                    dataTable = new DataTable();
                    dataTable = dataset.Tables[0];
                    return dataTable;
                }
            }
        }
    }


