﻿using System;



namespace HotelMgmt
{
    class Program
    {
        static void Main(string[] args)
        {
            Reservation reservation = new Reservation();
            while (true)
            {
                try
                {
                    Console.WriteLine("==================Welcome to the Hotel=======================\n");
                    Console.WriteLine("\n Enter Your Choice \n");
                    Console.WriteLine(" 1. Make a New Booking \n 2. Booking Details based on a Date \n 3. Exit");
                    int choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            {
                                NewBooking(reservation);

                                break;
                            }
                        case 2:
                            {
                                SearchByDate(reservation);
                                break;
                            }
                        case 3:
                            {
                                Console.WriteLine("____Exit From This Page____");
                                Environment.Exit(0);
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("______Invalid Choice______");
                                break;
                            }
                    }

                    Console.ReadLine();

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        private static void NewBooking(Reservation reservation)
        {
            Console.WriteLine("_______Make a New Booking_________");
            Console.WriteLine(" Please Enter the following Details");
            Console.WriteLine("Enter the Customer Id: ");
            int customerId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Date on which you want to check in(dd/mm/yy format)");
            DateTime checkInDate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter the Date on which you want to check out (dd/mm/yy format)");
            DateTime checkOutDate = Convert.ToDateTime(Console.ReadLine());

            ReservationDetail reservationDetail = reservation.CheckRoomAvailability(customerId, checkInDate, checkOutDate); ;
            if (reservationDetail != null)
            {
                Console.WriteLine("Booking Successful");
                bool status = reservation.DisplayAndAddBookingDetails(reservationDetail);
                if (status == true)
                {
                    Console.WriteLine("Room Booking Successful");
                }
                else
                {
                    Console.WriteLine("Room booking can't be done. Please try again later");
                }
            }
            else
            {
                Console.WriteLine("No rooms available for the selected dates. Please try with another set of dates");
            }
        }

        private static void SearchByDate(Reservation reservation)
        {
            Console.WriteLine("___ Display Booking Details based on a Date");
            Console.WriteLine("Enter the Date to view the Room Bookings (yyyy-mm-dd) ");
            DateTime searchDate = Convert.ToDateTime(Console.ReadLine());
            reservation.SearchByDate(searchDate);
        }
    }
}
